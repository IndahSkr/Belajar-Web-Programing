<?php
$user = $_POST['uname'];
$pass = $_POST['pass'];

echo "Welcome, ".$user."!";
?>